;
; lab4_2.asm 
;Name: Peter Feng
; class#: 11303
; Pi's Name: Grant
;description: intialize EBI and constantly write from input port to output port 




.include "ATxmega128A1Udef.inc"

;INITIALIZATIONS
 .equ SRAM_START_ADDR = 0xA68000
 .equ IO_START_ADDR = 0xBEE640
 .equ DATA_COUNT = 8 



 .org 0x0000
	rjmp MAIN

.org 0x0100
MAIN:
    ; Initialize the stack pointer
    ldi     r16, high(RAMEND)
    sts     CPU_SPH, r16
    ldi     r16, low(RAMEND)
    sts     CPU_SPL, r16


    ; Initialize the EBI I/O pins and the EBI system
    rcall   EBI_IO_INIT
    rcall   EBI_INIT

	; To access memory above 0xFFFF, we must use the
    ; Z-pointer along with the RAMPZ register.

    ; 1. Set up the Z-pointer and RAMPZ to point to our I/O address.
    ldi     ZL, Low(IO_START_ADDR)      ; Load low byte of address
    ldi     ZH, high(IO_START_ADDR)      ; Load high byte of address
    ldi     r16, byte3(IO_START_ADDR)      ; Load extended byte of address
    sts     CPU_RAMPZ, r16                  ; Store it in RAMPZ


MAIN_LOOP:


    ; 2. Read from the external input port (switches).
    ; The 'ld' instruction triggers an EBI read cycle. 
    ld    r17, Z       ; Read Z-pointer address into r17

    ; 3. Write to the external output port (LEDs).
    ;    The 'st' instruction triggers an EBI wriqte cycle. 
    st    Z, r17         ; Write from r17 to Z-pointer address

    ; 4. Repeat the process indefinitely.
    rjmp    MAIN_LOOP





/*--------------------------------------------------------------
  ebi_io_init --
  Description:
  Initialize and enable the EBI IO pins for hardware expansion.
--------------------------------------------------------------*/
EBI_IO_INIT: 	
  ; Preserve the relevant register.
  push r16  
  
  ; Initialize the relevant EBI control signals to be 
  ; in a `false` state.
  ;	ALE1 is false (L) by default.
  ; Set active-low EBI signals to false (H) 1s, RE(L) and CS0(L)
  ldi r16, 0b01010011
  sts PORTH_OUTSET, r16
  

  ldi r16, 0b00000100
  sts PORTH_OUTCLR, r16

  ; Initialize the EBI control signals to be output from 
  ; the microcontroller.
  ; 
  ldi r16, 0b01010111
  sts PORTH_DIRSET , r16   

  ; Initialize the address signals to be output
  ; from the microcontroller.
  ldi r16, 0xFF        
  sts PORTK_DIRSET, r16 

  ; Recover the relevant register.
  pop r16

   ; Return from subroutine.
  ret


/*--------------------------------------------------------------
 ebi_init --

 Description:
  Initialize and enable the EBI system for the relevant
  hardware expansion.
--------------------------------------------------------------*/
EBI_INIT: 
  push r16     

  ; Initialize the EBI system for SRAM 3-PORT ALE1 mode.
  ; Initialize EBI_CTRL for 3-port (H, J, K) (IFMODE), ALE1 (SRMODE)
  ; Instead of BIT0, can also use EBI_IFMODE_3PORT_gc | EBI_SRMODE_ALE1_gc 
  ldi r16, 0b00000001  
  sts EBI_CTRL, r16

  ; Initialize the relevant chip select(s).

  ; Configure chip select CS0
  ; set to 16k  space and turn on SRAM mode
  ; ldi r16, 0b00011101 
  ;sts EBI_CS0_CTRLA, r16 


;  ldi r16, byte2(SRAM_START_ADDR)   
  
 ; sts EBI_CS0_BASEADDR, r16 

  ;ldi r16, byte3(SRAM_START_ADDR) 

  ;sts EBI_CS0_BASEADDR+1, r16 

  
  ; Configure chip select CS2
  ; this is just : 0b00001101 
  ldi r16, 0b00001101
  sts EBI_CS2_CTRLA, r16  



  ;Load the middle byte (A15:8) of the 3-byte address into a   
;  register and store it as the LOW byte of the Base Address,
;  BASEADDRL.  This will store only bits A15:A12 and ignore
;  anything in A11:8 (assumed to be 0). 
;Initialize low byte of the EBI CS2 base address (byte2 of address).
   ldi r16, byte2(IO_START_ADDR) 
   sts EBI_CS2_BASEADDR, r16   

;Load the highest byte (A23:16) of the 3-byte address into a 
;  register and store it as the HIGH byte of the Base Address.
;Initialize high byte of the EBI CS2 base address (byte3 of address).
	ldi r16, byte3(IO_START_ADDR)     
	sts EBI_CS2_BASEADDR+1, r16 
  
	   ; Recover the relevant register.
  pop r16  

   ; Return from subroutine.
  ret

