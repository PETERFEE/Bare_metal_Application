;
; lab4_3a.asm 
;Name: Peter Feng
; class#: 11303
; Pi's Name: Grant
;Description: store all data forom the text file to SRAM and read from it 



.include "ATxmega128A1Udef.inc"

.org 0x0400 
DATA_START:
    .include "sram_data_asm.txt"
DATA_END:


;INITIALIZATIONS
.equ SRAM_START_ADDR = 0xA68000
.equ IO_START_ADDR = 0xBEE640


 .org 0x0000
	rjmp MAIN

.org 0x0100
MAIN:
    ; Initialize the stack pointer
    ldi     r16, high(RAMEND)
    sts     CPU_SPH, r16
    ldi     r16, low(RAMEND)
    sts     CPU_SPL, r16


    ; Initialize the EBI I/O pins and the EBI system
    rcall   EBI_IO_INIT
    rcall   EBI_INIT
	rcall   DELAY_INIT

	;WRITE DATA FROM PROGRAM MEMORY TO EXTERNAL SRAM
	; the data is at 0x000400
	ldi ZL, low(DATA_START * 2)  ; data memory is word addressed, multiply by 2 
	ldi ZH, high(DATA_START * 2) 
	; so the extend byte is 0; 
	clr r16
	sts CPU_RAMPZ, r16 

	; Set X-pointer to the start of the destination SRAM
    ldi     XL, low(SRAM_START_ADDR)
    ldi     XH, high(SRAM_START_ADDR)
    ldi     r16, byte3(SRAM_START_ADDR)
    sts     CPU_RAMPX, r16



WRITE_LOOP:
	
	lpm r16, Z+  ;load byte from program memory, and move to next address line 
	tst r16			; test if byte == 0 
	breq WRITE_DONE      ; If zero, exit loop
	st X+, r16	 ;store the data into SRAM and increment to next address line 
	rjmp WRITE_LOOP

WRITE_DONE:
    st X+, r16    ; put that null into SRAM too 

	; at this point all data has been store inside the SRAM

	;READ DATA FROM SRAM AND DISPLAY ON I/O PORT WITH DELAY ---
    ; Reset X-pointer to the start of the SRAM to read data back
    ldi     XL, low(SRAM_START_ADDR)
    ldi     XH, high(SRAM_START_ADDR)
    ldi     r16, byte3(SRAM_START_ADDR)
    sts     CPU_RAMPX, r16

	; Set Z-pointer to the I/O Port address for output
    ldi     ZL, low(IO_START_ADDR)
    ldi     ZH, high(IO_START_ADDR)
    ldi     r16, byte3(IO_START_ADDR)
    sts     CPU_RAMPZ, r16



	DISPLAY_LOOP:
    ld r17, X+           ; Read next byte from SRAM
    tst r17              ; Check if it's NULL (0x00)
    breq DONE            ; Stop when end of data
    st Z, r17            ; Output byte to I/O (LEDs)
    rcall DELAY_300MS
    rjmp DISPLAY_LOOP

DONE:
    rjmp    DONE        ; Program finished, enter an infinite loop
    

/*--------------------------------------------------------------
  ebi_io_init --
  Description:
  Initialize and enable the EBI IO pins for hardware expansion.
--------------------------------------------------------------*/
EBI_IO_INIT: 	
  ; Preserve the relevant register.
  push r16  
  
  ; Initialize the relevant EBI control signals to be 
  ; in a `false` state.
  ;	ALE1 is false (L) by default.
  ; Set active-low EBI signals to false (H) 1s, RE(L) and CS0(L)
  ldi r16, 0b01010011
  sts PORTH_OUTSET, r16
  

  ldi r16, 0b00000100
  sts PORTH_OUTCLR, r16

  ; Initialize the EBI control signals to be output from 
  ; the microcontroller.
  ; 
  ldi r16, 0b01010111
  sts PORTH_DIRSET , r16   

  ; Initialize the address signals to be output
  ; from the microcontroller.
  ldi r16, 0xFF        
  sts PORTK_DIRSET, r16 

  ; Recover the relevant register.
  pop r16

   ; Return from subroutine.
  ret


/*--------------------------------------------------------------
 ebi_init --

 Description:
  Initialize and enable the EBI system for the relevant
  hardware expansion.
--------------------------------------------------------------*/
EBI_INIT: 
  push r16     

  ; Initialize the EBI system for SRAM 3-PORT ALE1 mode.
  ; Initialize EBI_CTRL for 3-port (H, J, K) (IFMODE), ALE1 (SRMODE)
  ; Instead of BIT0, can also use EBI_IFMODE_3PORT_gc | EBI_SRMODE_ALE1_gc 
  ldi r16, 0b00000001  
  sts EBI_CTRL, r16

  ; Initialize the relevant chip select(s).

   ;Configure chip select CS0
  ; set to 16k  space and turn on SRAM mode
   ldi r16, 0b00011101 
  sts EBI_CS0_CTRLA, r16 

 ldi r16, byte2(SRAM_START_ADDR)   
  
 sts EBI_CS0_BASEADDR, r16 

  ldi r16, byte3(SRAM_START_ADDR) 

  sts EBI_CS0_BASEADDR+1, r16 

  
  ; Configure chip select CS2
  ; this is just : 0b00001101 
  ldi r16, 0b00001101
  sts EBI_CS2_CTRLA, r16  



  ;Load the middle byte (A15:8) of the 3-byte address into a   
;  register and store it as the LOW byte of the Base Address,
;  BASEADDRL.  This will store only bits A15:A12 and ignore
;  anything in A11:8 (assumed to be 0). 
;Initialize low byte of the EBI CS2 base address (byte2 of address).
   ldi r16, byte2(IO_START_ADDR) 
   sts EBI_CS2_BASEADDR, r16   

;Load the highest byte (A23:16) of the 3-byte address into a 
;  register and store it as the HIGH byte of the Base Address.
;Initialize high byte of the EBI CS2 base address (byte3 of address).
	ldi r16, byte3(IO_START_ADDR)     
	sts EBI_CS2_BASEADDR+1, r16 
  
	   ; Recover the relevant register.
  pop r16  

   ; Return from subroutine.
  ret

  DELAY_INIT:
	; Configure Timer/Counter's Period register for the 300ms delay
	;  2MHz system clock, choose prescaler = 64
	; f_timer = f_clk / 64 = 31250Hz
	; period = T_delay * f_timer = 0.3second * 31250Hz = 9375
	
	ldi r16, low(9375)
	sts TCC0_PER, r16 
	ldi r16, high(9375)
	sts TCC0_PER+1, r16 
	ret 

  DELAY_300MS: 
	; Start Timer/Conuter C0 with 64 prescaler 
	ldi r16, TC_CLKSEL_DIV64_gc
	sts TCC0_CTRLA, r16 

; it does nothing but repeatedly checking timer status 
 WAIT:
    lds     r16, TCC0_INTFLAGS ; load Interrupt Flags of timer in to r17.
    sbrc    r16, TC0_OVFIF_bp	; if TC0_OVFIF is 0, still counting
    rjmp    WAIT_END		; otherwise timer has reach and overflow 
    rjmp    WAIT
	
 WAIT_END:
	; Stop the timer and clear the flag before returning
    ldi     r16, TC_CLKSEL_OFF_gc
    sts     TCC0_CTRLA, r16
    ldi     r16, TC0_OVFIF_bm      ; Load the bit mask for the overflow flag
    sts     TCC0_INTFLAGS, r16      ; Write 1 to the flag to clear it
    ret



 

	


  
	
