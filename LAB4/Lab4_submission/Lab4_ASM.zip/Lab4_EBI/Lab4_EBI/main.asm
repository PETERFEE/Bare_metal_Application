;
; Lab4_EBI.asm
;
; Created: 10/8/2025 2:57:46 PM
; Author : fengh
;


; Replace with your application code
start:
    inc r16
    rjmp start
