;
; lab4_3b.asm
; Name: Peter Feng
; class#: 11303
; Pi's Name: Grant
; Description: Infinitely writes and reads to two SRAM locations
;              to allow for measurement of EBI read/write cycles
;              with a logic analyzer.


.include "ATxmega128A1Udef.inc"


; We need two addresses where the "middle byte" (A15-A8) is different.
; This forces the EBI to toggle the ALE1 signal when switching between them.
; Address 1: 0xA08000 -> Middle byte = 0x80
; Address 2: 0xA08100 -> Middle byte = 0x81
.equ SRAM_ADDR_1 = 0xA08000
.equ SRAM_ADDR_2 = 0xA08100

; Non-zero 4-bit values to write, making them visible on D3-D0.
; 0xAA = 10101010b
; 0x55 = 01010101b
.equ DATA_VAL_1 = 0xAA
.equ DATA_VAL_2 = 0x55


.org 0x0000
    rjmp MAIN

.org 0x0100
MAIN:
    ; Initialize the stack pointer
    ldi     r16, high(RAMEND)
    sts     CPU_SPH, r16
    ldi     r16, low(RAMEND)
    sts     CPU_SPL, r16

    ; Initialize the EBI I/O pins and the EBI system
    rcall   EBI_IO_INIT
    rcall   EBI_INIT

; This infinite loop will continuously generate write and read cycles
; to the two specified addresses for capture.
MEASUREMENT_LOOP:
    ; ACCESS ADDRESS 1 
    ; Set X-pointer to the first SRAM address
    ldi     XL, low(SRAM_ADDR_1)
    ldi     XH, high(SRAM_ADDR_1)
    ldi     r16, byte3(SRAM_ADDR_1)
    sts     CPU_RAMPX, r16
    
    ; Write first data value to SRAM
    ldi     r17, DATA_VAL_1 
    st      X, r17          ; 1. capture EBI write cycle

    ; Read the data back from SRAM
    ld      r18, X          ;  2. Capture EBI Read cycle


    ; ACCESS ADDRESS 2
    ; Set X-pointer to the second SRAM address.
    ; This address change will trigger the ALE1 signal.
    ldi     XL, low(SRAM_ADDR_2)
    ldi     XH, high(SRAM_ADDR_2)
    ldi     r16, byte3(SRAM_ADDR_2)
    sts     CPU_RAMPX, r16
    
    ; Write second data value to SRAM
    ldi     r17, DATA_VAL_2 ; 
    st      X, r17          ;  1. capture write cycle

    ; Read the data back from SRAM
    ld      r18, X          ;  2. Capture Read cycle 

    ; Repeat forever
    rjmp    MEASUREMENT_LOOP


/*--------------------------------------------------------------
 ebi_io_init --
 Description:
 Initialize and enable the EBI IO pins for hardware expansion.
--------------------------------------------------------------*/
EBI_IO_INIT:
    push    r16
    ldi     r16, 0b01010011
    sts     PORTH_OUTSET, r16
    ldi     r16, 0b00000100
    sts     PORTH_OUTCLR, r16
    ldi     r16, 0b01010111
    sts     PORTH_DIRSET, r16
    ldi     r16, 0xFF
    sts     PORTK_DIRSET, r16
    pop     r16
    ret

/*--------------------------------------------------------------
 ebi_init --
 Description:
 Initialize and enable the EBI system for the relevant
 hardware expansion.
--------------------------------------------------------------*/
EBI_INIT:
    push    r16
    ; Initialize the EBI system for SRAM 3-PORT ALE1 mode.
    ldi     r16, 0b00000001
    sts     EBI_CTRL, r16

    ; Configure chip select CS0 for SRAM
    ldi     r16, 0b00011101
    sts     EBI_CS0_CTRLA, r16
    ldi     r16, byte2(SRAM_ADDR_1)
    sts     EBI_CS0_BASEADDR, r16
    ldi     r16, byte3(SRAM_ADDR_1)
    sts     EBI_CS0_BASEADDR+1, r16
    
    pop     r16
    ret