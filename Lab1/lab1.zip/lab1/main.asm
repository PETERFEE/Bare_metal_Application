;************************************************************************
;  Lab 1, Section 2
;  Name: Peter Feng
;  Class #: 11303
;  PI Name: Grant
;  Description: To filter data stored within a predefined input table 
;				based on a set of given conditions and store 
;				a subset of filtered values into an output table.
;************************************************************************
;*********************************INCLUDES*******************************
.include "ATxmega128a1udef.inc"   
;***********END OF INCLUDES******************************
;*********************************EQUATES********************************
; potentially useful expressions
.equ NULL = 0 
.equ ThirtySeven = 3*7 + 37/3 - (3-7)  ; 21 + 12 + 4

;***********END OF EQUATES*******************************
;***********MEMORY CONFIGURATION*************************
; program memory constants (if necessary)
.cseg		; indicate a start of program memory
.org 0xDADD  ; start on input table address
IN_TABLE:   ; label marking the start of the input table 
;enter all the data in the pdf Table 1
.db	0x21, 0xB4, 0x34,0x38, 0xDA, 0xE4, 0xB8, 0x47, 0x6E, 0x76, 0x2E, 0xD0, 0xCC, 0x32, 0x7D
.db NULL  ; the final byte of the table is null 
; label below is used to calculate size of input table
IN_TABLE_END: ; mark the end of the input table 


; data memory allocation (if necessary)
.dseg			; indicate of the start of data memory 
; initialize the output table starting address
.org 0x3744  ; start of the output table address 
OUT_TABLE:		; mark the start of the out table 
.byte (IN_TABLE_END - IN_TABLE) ; use byte to reserve the same number of byte as input table length in this address 
;***********END OF MEMORY CONFIGURATION***************




;***********MAIN PROGRAM*******************************
.cseg       ; indicate start of program memory 
; configure the reset vector 
;	(ignore meaning of "reset vector" for now)
.org 0x0
	rjmp MAIN 

; place main program after interrupt vectors 
;	(ignore meaning of "interrupt vectors" for now)
.org 0x100 ; the main program starts at 0x100
MAIN:
; point appropriate indices to input/output tables . 
;RAMP is needed because 0xDADD * 2 is over 0x10000
; Since IN_TABLE in program memory with word address, *2 to get Byte address
; we need 3 register:  ZH(15..8), ZL(7..0)

;ldi don't work with i/o register, load to r16 first 
ldi r16, (IN_TABLE*2)>>16 ; bits 23..16 → 0x01
;refer as CPU_RAMPZ
out CPU_RAMPZ, r16             ; set RAMPZ for LPM


;load low bits to ZL
	ldi ZL, low(IN_TABLE*2)  
	
;load high 15..8 bits 
	ldi ZH, byte2(IN_TABLE*2) 

;use Y-pointer for out-table

	ldi YL, low(OUT_TABLE) ;load low byte of the out_table

	ldi YH,high(OUT_TABLE) ;load high byte of the out_table

; loop through input table, performing filtering and storing conditions
LOOP:
	; load value from input table into an appropriate register
	
	elpm r16, Z+  ; load what's pointed by Z (in_table) into r16
				  ; increment Z to point to next element in the table

	; determine if the end of table has been reached (perform general check)
	cpi r16, null ; compare element in the r16 with null 
				; it's substracting null from r16
				;and set Z-flag = 1 if the result is 0
				
	; if end of table (EOT) has been reached, i.e., the NULL character was 
	; encountered, the program should branch to the relevant label used to
	; terminate the program (e.g., DONE)

		breq DONE ; branch if they are equal 
			 ; it's just checking if Z-flag = 1 then jump to DONE
			 ;if Z = 0, execution next instruction

	; if EOT was not encountered, perform the first specified 
	; overall conditional check on loaded value (CONDITION_1)
CHECK_1:
	; check if the CONDITION_1 is met (bit 7 of # is cleared); 
	;   if not, branch to FAILED_CHECK1
	sbrc r16,7 ; skip if Bit in Register is clear 
				;  if bit7(MSB) of r16 is 0 (clear) then skip next instruction 
				; if bit 7 = 1 , go to next instruction 
	
	rjmp FAILED_CHECK1
	
	; since the CONDITION_1 is met, perform the specified operation
	;   (multiply # by 2, unsigned)
	lsl r16 ; logical shift left to multiple the value in r16 by 2


	; check if CONDITION_1a is met (result < 111); if so, then 
	;   jump to LESS_THAN_111; else store nothing and go back to LOOP
	cpi r16, 111 ; set C-flag (carry) = 1 if there's a borrow 
				; there's a borrow if r16 < 111
	brlo LESS_THAN_111 ; branch if lower (unsigned) 
						; it checks if C-flag = 1, jump to label
						; if c-flag = 0, falls through 

	rjmp LOOP

LESS_THAN_111:
	; add 12 and store the result
	;we can't use adiw on r16 because it only works on r24..r31
	subi r16, -12 ; substract immediate r16 - (-12) = r16 + 12
	st Y+, r16 ; store the result in r16 to Y(output_table) 
				; move the pointer to next byte of the table 

	rjmp LOOP
	
FAILED_CHECK1:
	; since the CONDITION_1 is NOT met (bit 7 of # is set),
	;    perform the second specified operation 
	;    (divide by 2 [unsigned])
	lsr r16   ;logical shift right to divide by 2


	; check if CONDITION_2b is met (result >= 71); if so, jump to
	;    GREATER_EQUAL_71 (and do the next specified operation);
	;    else store nothing and go back to LOOP	

	cpi	r16, 71  ; c = 1 if r16 < 70  (borrow occurred)
	brsh GREATER_EQUAL_71 ;if c = 0 , r16 >= 70(no borrow) -> branch 
							; if c = 1 r16 < 70(borrow) -> next instruction


	rjmp LOOP
	
GREATER_EQUAL_71:
	; add 7 and store the result 
	subi r16, -7
	st Y+, r16
	;go back to LOOP
	rjmp LOOP
	
; end of program (infinite loop)
DONE: 
	rjmp DONE
;***********END OF MAIN PROGRAM **********************