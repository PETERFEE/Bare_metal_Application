; ;
;lab3_2b.asm , section 17b
;Name: Peter Feng
; class#: 11303
; Pi Name: Grant
;description: Debounce s1 interrupt 


.include "ATxmega128a1udef.inc"


;defined the counter register to keep track of the time that pass
.def counter = r16
; --- MODIFICATION ---
; Defined r17 as temp for clarity, as it is used throughout
.def temp = r17

.org 0x0000
    rjmp RESET_INIT ; reset the interrupt

;PortF2 is s1
; Set the vector for Port F's Interrupt 0
.org (PORTF_INT0_vect * 2)   ; * 2 to give .org its byte address 
    rjmp    S1_PRESSED_ISR		


; Added the interrupt vector for the debounce timer : TCD0
.org (TCD0_OVF_vect * 2)     ;* 2 to give .org its byte address 
    rjmp    DEBOUNCE_TIMER_ISR


RESET_INIT:
     ; --- Initialize Stack Pointer ---
    ldi     r17, high(RAMEND)
    sts     CPU_SPH, r17
    ldi     r17, low(RAMEND)
    sts     CPU_SPL, r17

    ; initailze the counter to 0
    clr     counter

    ;set PORTC as outputs
    ldi r17, 0xFF
    sts PORTC_DIR, r17
    sts PORTC_OUT, r17 ; turn off all LEDs

    ;set PORTD, pin 6 which is BLUE_PWM LED as output
    ldi r17, 0b01000000
    sts PORTD_DIRSET, r17

    ; initally turn it off, since it's active low, write 1 into it
    sts PORTD_OUTSET, r17

    ; Set PORTF2 (S1) into input
    ldi r17, 0b00000100
    sts PORTF_DIRCLR, r17


    ;Configure Interrupt for S1
    ; Configure PF2 to trigger on a (button press) falling edge
    ; to select "Pull-up (on input)", the OPC bits [5:3] must be 011
    ; to "Sense falling edge", the ISC bits [2:0] must be 010
    ; PORT_OPC_PULLUP_gc = 0x18, PORT_ISC_FALLING_gc = 0x02.
    ;                         bitwise OR to combine 2 together
    ldi     r17, PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc
    sts     PORTF_PIN2CTRL, r17

    ; decide which pin on Port F
    ;are triggering the Interrupt 0 signal

 
    ; Corrected the bitmask. 0b00000100 is for Pin 2.
    ldi r17, 0b00000100   
    ; Port F's Interrupt 0, only use Pin 2.
    sts PORTF_INT0MASK, r17

            ;gc apply to interrupt 0 , set prority to low
    ldi r17, PORT_INT0LVL_LO_gc
    ;eable interrupt at the source
    sts PORTF_INTCTRL, r17

 
    ; Add configuration for the debounce timer (TCD0).
    ; We set it up for a 10ms delay. 
    ; Calculation: PER = (Delay * Clock / Prescaler) 
    ; PER = (0.010s * 2,000,000Hz / 64)  = 312
    ldi     r17, high(312)
    sts     TCD0_PER+1, r17
    ldi     r17, low(312)
    sts     TCD0_PER, r17

    ; Enable the overflow interrupt for debounce timer at a low level.
    ldi     temp, TC_OVFINTLVL_LO_gc
    sts     TCD0_INTCTRLA, temp


    ; Enable low-level interrupts in the PMIC
    ldi     r17, PMIC_LOLVLEN_bm ; PMIC_LOLVLEN_bm = 0x01. Low Level Interrupt Enable bit.
    sts     PMIC_CTRL, r17

    ; Enable global interrupts
    sei

;this is the background task that continously running
MAIN_LOOP:
    ldi r17, 0b01000000 ; pin6
    sts PORTD_OUTTGL, r17 ; toggle the blue LED
    rjmp MAIN_LOOP          ; without delay


; This first ISR triggers immediately on a press to start the debounce timer.
S1_PRESSED_ISR:
    ; Disable the switch interrupt to ignore bounces
    ldi     r17, PORT_INT0LVL_OFF_gc
    sts     PORTF_INTCTRL, r17

    ; Start the 30ms debounce timer with a prescaler of 64
    ldi     r17, TC_CLKSEL_DIV64_gc 
    sts     TCD0_CTRLA, r17  

    reti

; This second ISR triggers ONLY after the 30ms debounce timer overflows.
DEBOUNCE_TIMER_ISR:
    ; since the main is actively using the r17 to toggle the blue LED
    ; ISR also needs r17 for its own caculation
    ; we need to save a copy of what's in r17 onto stack
    push    r17
    in      r17, CPU_SREG ; this copy all status register like the zero  flags
                          ; and save a copy on the stack
    push    r17

    ;Stop the debounce timer, it is no longer needed
    ldi     r17, TC_CLKSEL_OFF_gc   
    sts     TCD0_CTRLA, r17	

    ; Check if the switch is still pressed after the delay
    lds     r17, PORTF_IN      
    sbrs    r17, 2             ; Skip the next instruction if bit 2 is 1 (released)
    rjmp    VALID_PRESS         ; If bit 2 is still 0 (pressed), it's a valid press


    ; The PORTF2 is 1 the switch was released during the delay (it was a bounce) pressed and quickly released.
    ; We jump directly to the reset routine without incrementing the counter.
    rjmp    RESET_SWITCH_INTERRUPT 

VALID_PRESS:
    inc     counter ; increment the counter

    ; LED is active low, that's why we complement it
    mov     r17, counter ; copy what's in counter into r17
    com     r17 ; complement r17 , 0 to 1, 1 to 0
    sts     PORTC_OUT, r17 ; update the LED with this count


RESET_SWITCH_INTERRUPT:
    ; this will clear the interrupt flag, so this ISR doesn't triger again
    ldi     r17, PORT_INT0IF_bm 
    sts     PORTF_INTFLAGS, r17

    ; Re-enable the switch interrupt for the next press
    ldi     r17, PORT_INT0LVL_LO_gc 
    sts     PORTF_INTCTRL, r17

    pop     r17           ;get the last saved copy of SREG—from the stack and puts it back into r17.
    out     CPU_SREG, r17
    pop     r17

    ;Return from Interrupt back to main loop where it left off
    reti