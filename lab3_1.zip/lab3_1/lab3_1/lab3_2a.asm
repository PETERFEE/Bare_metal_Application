;
;lab3_2.asm , section 17b
;Name: Peter Feng
; class#: 11303
; Pi Name: Grant
;description: configure an I/O port interrupt so that responses to a tactile switch on the OOTB
;SLB can be made asynchronously. 


.include "ATxmega128a1udef.inc"

;defined the counter register to keep track of the time that pass
.def counter = r16 

.org 0x0000
	rjmp RESET_INIT ; reset the interrupt 

;PortF2 is s1
; Set the vector for Port F's Interrupt 0
.org PORTF_INT0_vect
    rjmp    S1_PRESSED_ISR 

RESET_INIT:
	 ; --- Initialize Stack Pointer ---
    ldi     r17, high(RAMEND)
    sts     CPU_SPH, r17
    ldi     r17, low(RAMEND)
    sts     CPU_SPL, r17

	; initailze the counter to 0 
    clr     counter

	;set PORTC as outputs 
	ldi r17, 0xFF
	sts PORTC_DIR, r17 
	sts PORTC_OUT, r17 ; turn off all LEDs 

	;set PORTD, pin 6 which is BLUE_PWM LED as output
	ldi r17, 0b01000000
	sts PORTD_DIRSET, r17 
		
	; initally turn it off, since it's active low, write 1 into it 
	sts PORTD_OUTSET, r17 

	; Set PORTF2 (S1) into input 
	ldi r17, 0b00000100   
	sts PORTF_DIRCLR, r17 


	;Configure Interrupt for S1 
    ; Configure PF2 to trigger on a (button press) falling edge
	; to select "Pull-up (on input)", the OPC bits [5:3] must be 011
	; to "Sense falling edge", the ISC bits [2:0] must be 010
	; PORT_OPC_PULLUP_gc = 0x18, PORT_ISC_FALLING_gc = 0x02.
	;                        bitwise OR to combine 2 together 
    ldi     r17, PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc
    sts     PORTF_PIN2CTRL, r17

	; decide which pin on Port F 
	;are triggering the Interrupt 0 signal 
	ldi r17, 0b00000100
	; Port F's Interrupt 0, only use Pin 2.
	sts PORTF_INT0MASK, r17 

			;gc apply to interrupt 0 , set prority to low 
	ldi r17, PORT_INT0LVL_LO_gc
	;eable interrupt at the source 
	sts PORTF_INTCTRL, r17

	
    ; Enable low-level interrupts in the PMIC
    ldi     r17, PMIC_LOLVLEN_bm ; PMIC_LOLVLEN_bm = 0x01. Low Level Interrupt Enable bit.
    sts     PMIC_CTRL, r17 

    ; Enable global interrupts
    sei

;this is the background task that continously running 
MAIN_LOOP:
	ldi r17, 0b01000000 ; pin6 
	sts PORTD_OUTTGL, r17 ; toggle the blue LED
	rjmp MAIN_LOOP			; without delay 

S1_PRESSED_ISR:
	;since the main is actively using the r17 to toggle the blue LED
	; ISR also needs r17 for its own caculation 
	; we need to save a copy of what's in r17 onto stack 
	push r17  
	in  r17, CPU_SREG ; this copy all status register like the zero  flags 
					  ; and save a copy on the stack
	push r17


	inc counter ; increment the counter 

	; LED is active low, that's why we complement it 
	mov r17, counter ; copy what's in counter into r17
	com r17 ; complement r17 , 0 to 1, 1 to 0 
	sts PORTC_OUT, r17 ; update the LED with this count  

	; this will clear the interrupt flag, so this ISR doesn't triger again
	ldi     r17, PORT_INT0IF_bm
    sts     PORTF_INTFLAGS, r17

	pop     r17       ;get the last saved copy of SREG—from the stack and puts it back into r17.
    out     CPU_SREG, r17
    pop     r17


	;Return from Interrupt back to main loop where it left off 
	reti 






	

