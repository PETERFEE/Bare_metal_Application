;
; lab3_1.asm , section 17b
;Name: Peter Feng
; class#: 11303
; Pi's Name: Grant
;description: configure a t/C to trigger overflow interrupt every 37ms


.include "ATxmega128a1udef.inc"


.org 0x0000 
	rjmp reset 

.org TCC0_OVF_vect
	rjmp TCC0_OVF_ISR 


.org 0x0100
reset:
	ldi r16, low(RAMEND)
	sts CPU_SPL, r16 
	ldi r16, high(RAMEND)
	sts CPU_SPH, r16

	; initailize the output pins
	ldi r16, 0x01
	sts PORTC_DIRSET, r16 
	

	;Configure Timer C0 for 37ms overflow
	; PER = (output delay * clock rate )/ prescaler 
	; PER = (0.037s * 2000000Hz ) / prescaler 
	; to make PER under 2^16 which is 65536 
	; try prescaler 2
	; 74000/2 = 37000 < 65536
	ldi r16, high(37000)
	sts TCC0_PER+1, r16 
	ldi r16, low(37000)
	sts TCC0_PER, r16 

	; enable all 3 level of interrupt 

	; telling peripheral deveice that it can send a low level interrupt 
	; overflow/interrupt   L0 means low priority , gc is predefind value that i can use 
	ldi r16, TC_OVFINTLVL_LO_gc 	; This is 0x01 
	sts TCC0_INTCTRLA, r16 ; feed it through interrupt control 

	; The PMIC level, the gatekeeper 
	; 
				;Low level enable 
	ldi r16, PMIC_LoLVLEN_bm  ; load 1 
	sts PMIC_CTRL, r16     ; to enable interrupt being process

	; Global Master Switch 
	sei  ; enable global interrupt 

	; start Timer with prescaler  = 2 
	ldi r16, 0x02
	sts TCC0_CTRLA, r16 

main_loop:
	; it does nothing but wait for the interrupt to happend 
	rjmp main_loop

;timer overflow ISR
TCC0_OVF_ISR: ; excute when timer overflow 
	;toggle portc output pin 
	ldi r16, 0x01
	sts PORTC_OUTTGL, r16
	reti ; return the prorgam and wait for more interrupt 











